import { useState, useEffect, useMemo } from 'react'
import { List, Plus, Pencil, AlertCircle, X, Clock3 } from 'lucide-react'
import './TaskManager.css'

const STAGES = [
  { id: 'todo', label: 'Todo', color: '#a78bfa' },
  { id: 'in-progress', label: 'In Progress', color: '#60a5fa' },
  { id: 'review', label: 'Review', color: '#fbbf24' },
  { id: 'done', label: 'Done', color: '#34d399' }
]

const PRIORITIES = ['critica', 'alta', 'media', 'baixa']
const PRIORITY_CONFIG = {
  baixa: { label: 'Baixa', color: '#6b7280', bg: 'rgba(107, 114, 128, 0.15)' },
  media: { label: 'Media', color: '#3b82f6', bg: 'rgba(59, 130, 246, 0.15)' },
  alta: { label: 'Alta', color: '#f59e0b', bg: 'rgba(245, 158, 11, 0.15)' },
  critica: { label: 'Critica', color: '#ef4444', bg: 'rgba(239, 68, 68, 0.15)' }
}

const emptyTask = {
  title: '',
  description: '',
  assignee: '',
  priority: 'media',
  status: 'todo',
  deliverableLink: '',
}

function formatDate(iso) {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleDateString('ca-ES', { day: '2-digit', month: 'short', year: 'numeric' })
  } catch {
    return iso
  }
}

export default function TaskManager() {
  const [tasks, setTasks] = useState([])
  const [chiefs, setChiefs] = useState([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({ assignee: 'all', status: 'all', priority: 'all' })
  const [editingTask, setEditingTask] = useState(null)
  const [isCreating, setIsCreating] = useState(false)
  const [form, setForm] = useState(emptyTask)
  const [note, setNote] = useState('')

  const load = async () => {
    setLoading(true)
    try {
      const [boardRes, orgRes] = await Promise.all([
        fetch('/api/pm-board').then(r => r.json()),
        fetch('/api/org-chart').then(r => r.json()),
      ])
      setTasks(boardRes.tasks || [])
      setChiefs(orgRes.chiefs || [])
    } catch {
      setTasks([])
      setChiefs([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    Promise.resolve().then(() => load())
  }, [])

  const filteredTasks = useMemo(() => {
    return tasks.filter(task => {
      if (filters.assignee !== 'all' && task.assignee !== filters.assignee) return false
      if (filters.status !== 'all' && task.status !== filters.status) return false
      if (filters.priority !== 'all' && task.priority !== filters.priority) return false
      return true
    })
  }, [tasks, filters])

  const handleCreate = () => {
    setIsCreating(true)
    setEditingTask(null)
    setForm({ ...emptyTask, assignee: chiefs[0]?.agentId || '' })
    setNote('')
  }

  const handleEdit = (task) => {
    setEditingTask(task)
    setIsCreating(false)
    setForm({
      title: task.title || '',
      description: task.description || '',
      assignee: task.assignee || '',
      priority: task.priority || 'media',
      status: task.status || 'todo',
      deliverableLink: task.deliverableLink || '',
    })
    setNote('')
  }

  const handleSave = async () => {
    if (isCreating) {
      await fetch('/api/pm-board', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, movedBy: 'Navi' })
      })
    } else if (editingTask) {
      await fetch(`/api/pm-board/${editingTask.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, note, movedBy: 'Navi' })
      })
    }
    setEditingTask(null)
    setIsCreating(false)
    setForm(emptyTask)
    setNote('')
    load()
  }

  const getStageConfig = (stageId) => STAGES.find(s => s.id === stageId) || STAGES[0]
  const chiefById = Object.fromEntries(chiefs.map(chief => [chief.agentId, chief]))

  if (loading) return <div className="task-manager"><div className="tm-empty">Carregant...</div></div>

  return (
    <>
      <div className="task-manager">
        <div className="tm-header">
          <h2><List size={16} /> PM Board</h2>
          <span className="tm-count">{tasks.length} tasques</span>
        </div>

        <div className="tm-toolbar">
          <select className="tm-filter active" value={filters.assignee} onChange={e => setFilters({ ...filters, assignee: e.target.value })}>
            <option value="all">Tots els chiefs</option>
            {chiefs.map(chief => <option key={chief.agentId} value={chief.agentId}>{chief.emoji} {chief.name}</option>)}
          </select>
          <select className="tm-filter" value={filters.status} onChange={e => setFilters({ ...filters, status: e.target.value })}>
            <option value="all">Tots els estats</option>
            {STAGES.map(stage => <option key={stage.id} value={stage.id}>{stage.label}</option>)}
          </select>
          <select className="tm-filter" value={filters.priority} onChange={e => setFilters({ ...filters, priority: e.target.value })}>
            <option value="all">Totes les prioritats</option>
            {PRIORITIES.map(priority => <option key={priority} value={priority}>{PRIORITY_CONFIG[priority].label}</option>)}
          </select>
          <div style={{ flex: 1 }} />
          <button className="tm-filter active" onClick={handleCreate}>
            <Plus size={14} /> Nova
          </button>
        </div>

        <div className="tm-table-wrapper">
          <table className="tm-table">
            <thead>
              <tr>
                <th>Tasca</th>
                <th>Prioritat</th>
                <th>Estat</th>
                <th>Chief</th>
                <th>Updated</th>
                <th>Deliverable</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody>
              {filteredTasks.length === 0 && (
                <tr><td colSpan={7} className="tm-empty">Cap tasca</td></tr>
              )}
              {filteredTasks.map(task => {
                const stageConfig = getStageConfig(task.status)
                const priorityCfg = PRIORITY_CONFIG[task.priority] || PRIORITY_CONFIG.baixa
                const chief = chiefById[task.assignee]
                return (
                  <tr key={task.id} className={task.stale ? 'tm-row-stale' : ''} onClick={() => handleEdit(task)}>
                    <td className="tm-title-cell">
                      <div className="tm-title">{task.title}</div>
                      <div className="tm-client">{task.description || task.id}</div>
                      {task.stale && <div className="tm-stale"><Clock3 size={11} /> stale 5+d</div>}
                    </td>
                    <td>
                      <span className="priority-badge" style={{ color: priorityCfg.color, background: priorityCfg.bg }}>{priorityCfg.label}</span>
                    </td>
                    <td>
                      <span className="stage-badge" style={{ background: `${stageConfig.color}20`, color: stageConfig.color }}>
                        <span className="stage-dot" style={{ background: stageConfig.color }} />
                        {stageConfig.label}
                      </span>
                    </td>
                    <td className="tm-assignee">{chief ? `${chief.emoji} ${chief.name}` : task.assignee}</td>
                    <td className="tm-date">{formatDate(task.updatedDate)}</td>
                    <td className="tm-assignee">{task.deliverableLink ? 'Link' : '—'}</td>
                    <td>
                      {Array.isArray(task.notes) && task.notes.length > 0 && (
                        <span className="tm-blockers"><AlertCircle size={12} /> {task.notes[task.notes.length - 1].text}</span>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {(editingTask || isCreating) && (
        <div className="tm-edit-overlay" onClick={() => { setEditingTask(null); setIsCreating(false) }}>
          <div className="tm-edit-modal" onClick={e => e.stopPropagation()}>
            <div className="tm-edit-header">
              <h3>{isCreating ? 'Nova Tasca PM' : 'Editar Tasca PM'}</h3>
              <button className="tm-edit-close" onClick={() => { setEditingTask(null); setIsCreating(false) }}><X size={16} /></button>
            </div>
            <div className="tm-edit-body">
              <div className="tm-field">
                <label>Titol</label>
                <input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
              </div>
              <div className="tm-field">
                <label>Descripcio</label>
                <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div className="tm-field">
                  <label>Status</label>
                  <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                    {STAGES.map(stage => <option key={stage.id} value={stage.id}>{stage.label}</option>)}
                  </select>
                </div>
                <div className="tm-field">
                  <label>Prioritat</label>
                  <select value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })}>
                    {PRIORITIES.map(priority => <option key={priority} value={priority}>{PRIORITY_CONFIG[priority].label}</option>)}
                  </select>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div className="tm-field">
                  <label>Chief Assignee</label>
                  <select value={form.assignee} onChange={e => setForm({ ...form, assignee: e.target.value })}>
                    {chiefs.map(chief => <option key={chief.agentId} value={chief.agentId}>{chief.emoji} {chief.name}</option>)}
                  </select>
                </div>
                <div className="tm-field">
                  <label>Deliverable Link</label>
                  <input value={form.deliverableLink} onChange={e => setForm({ ...form, deliverableLink: e.target.value })} />
                </div>
              </div>
              {!isCreating && (
                <div className="tm-field">
                  <label>Nota de transicio</label>
                  <textarea value={note} onChange={e => setNote(e.target.value)} placeholder="Quin canvi s'ha fet i per qui" />
                </div>
              )}
              {!isCreating && editingTask?.history?.length > 0 && (
                <div className="tm-field">
                  <label>Historial</label>
                  <div className="tm-history">
                    {editingTask.history.slice().reverse().map((entry, idx) => (
                      <div key={idx} className="tm-history-item">
                        <div>{entry.action} · {entry.from ? `${entry.from} → ` : ''}{entry.to || '—'}</div>
                        <div>{entry.by} · {formatDate(entry.at)}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div className="tm-edit-footer">
              <button className="tm-btn tm-btn-cancel" onClick={() => { setEditingTask(null); setIsCreating(false) }}>Cancelar</button>
              <button className="tm-btn tm-btn-save" onClick={handleSave} disabled={!form.title || !form.assignee}>{isCreating ? 'Crear' : 'Guardar'}</button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
