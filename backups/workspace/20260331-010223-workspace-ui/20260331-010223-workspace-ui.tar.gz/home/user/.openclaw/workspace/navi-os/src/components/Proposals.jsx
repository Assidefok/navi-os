import { useState, useEffect } from 'react'
import { Lightbulb, Check, X, Clock } from 'lucide-react'
import './Proposals.css'

export default function Proposals() {
  const [proposals, setProposals] = useState([])
  const [loading, setLoading] = useState(true)
  const [showHistory, setShowHistory] = useState(false)

  const loadProposals = () => {
    setLoading(true)
    fetch('/api/proposals')
      .then(r => r.json())
      .then(d => {
        setProposals(d.proposals || [])
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }

  useEffect(() => {
    Promise.resolve().then(() => loadProposals())
  }, [])

  const updateProposal = (id, status) => {
    fetch(`/api/proposals/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    })
      .then(r => r.json())
      .then(() => loadProposals())
      .catch(() => {})
  }

  const pending = proposals.filter(p => p.status === 'pending')
  const history = proposals.filter(p => p.status !== 'pending')

  if (loading) {
    return <div className="proposal-loading"><Clock size={18} /> Carregant...</div>
  }

  return (
    <div className="proposals-panel">
      <div className="proposals-header">
        <h3><Lightbulb size={16} /> Propostes de Millora</h3>
        <span className="proposals-count">{pending.length} pendents</span>
      </div>

      {pending.length === 0 && (
        <div className="proposal-empty">
          <Lightbulb size={24} style={{ opacity: 0.3, marginBottom: 8 }} />
          <p>No hi ha propostes pendents. Les acceptades o en curs surten de la vista principal.</p>
        </div>
      )}

      {pending.length > 0 && (
        <div className="proposals-list">
          {pending.map(p => (
            <div key={p.id} className="proposal-card pending">
              <div className="proposal-header">
                <span className="proposal-title">{p.title}</span>
                <span className="proposal-status pending">Pendent</span>
              </div>
              <p className="proposal-description">{p.description}</p>
              <div className="proposal-meta">
                Creat: {new Date(p.createdAt).toLocaleDateString('ca-ES')}
              </div>
              <div className="proposal-actions">
                <button className="proposal-btn accept" onClick={() => updateProposal(p.id, 'accepted')}>
                  <Check size={14} /> Acceptar
                </button>
                <button className="proposal-btn reject" onClick={() => updateProposal(p.id, 'rejected')}>
                  <X size={14} /> Rebutjar
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {history.length > 0 && (
        <div className="proposal-history-wrap">
          <button className="proposal-history-toggle" onClick={() => setShowHistory(!showHistory)}>
            {showHistory ? 'Amagar historial' : `Veure historial (${history.length})`}
          </button>
          {showHistory && (
            <div className="proposals-list" style={{ marginTop: 12 }}>
              {history.map(p => (
                <div key={p.id} className={`proposal-card ${p.status}`}>
                  <div className="proposal-header">
                    <span className="proposal-title">{p.title}</span>
                    <span className={`proposal-status ${p.status}`}>{p.status}</span>
                  </div>
                  <p className="proposal-description">{p.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
