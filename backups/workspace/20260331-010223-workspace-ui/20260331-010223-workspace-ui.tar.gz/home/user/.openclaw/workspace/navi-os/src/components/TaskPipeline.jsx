import { useState, useEffect, useMemo } from 'react'
import { Plus, AlertCircle, MessageSquare, Trash2, Pencil, CheckCircle2, Clock3, X } from 'lucide-react'
import './TaskPipeline.css'

const STAGES = [
  { id: 'todo', label: 'Todo', color: '#a78bfa' },
  { id: 'in-progress', label: 'In Progress', color: '#60a5fa' },
  { id: 'review', label: 'Review', color: '#fbbf24' },
]

const PRIORITIES = ['critica', 'alta', 'media', 'baixa']
const PRIORITY_CONFIG = {
  baixa: { label: 'Baixa', color: '#6b7280', bg: 'rgba(107, 114, 128, 0.15)' },
  media: { label: 'Media', color: '#3b82f6', bg: 'rgba(59, 130, 246, 0.15)' },
  alta: { label: 'Alta', color: '#f59e0b', bg: 'rgba(245, 158, 11, 0.15)' },
  critica: { label: 'Critica', color: '#ef4444', bg: 'rgba(239, 68, 68, 0.15)' }
}

const emptyTask = {
  title: '',
  description: '',
  assignee: '',
  priority: 'media',
  status: 'todo',
  deliverableLink: '',
}

function formatDate(iso) {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleDateString('ca-ES', { day: '2-digit', month: 'short' })
  } catch {
    return iso
  }
}

export default function TaskPipeline() {
  const [tasks, setTasks] = useState([])
  const [chiefs, setChiefs] = useState([])
  const [selectedAgent, setSelectedAgent] = useState('all')
  const [showDone, setShowDone] = useState(false)
  const [editingTask, setEditingTask] = useState(null)
  const [isCreating, setIsCreating] = useState(false)
  const [form, setForm] = useState(emptyTask)
  const [note, setNote] = useState('')

  const load = async () => {
    try {
      const [boardRes, orgRes] = await Promise.all([
        fetch('/api/pm-board').then(r => r.json()),
        fetch('/api/org-chart').then(r => r.json()),
      ])
      setTasks(boardRes.tasks || [])
      setChiefs((orgRes.chiefs || []).filter(chief => chief.agentId !== 'navi-chief'))
    } catch {
      setTasks([])
      setChiefs([])
    }
  }

  useEffect(() => {
    Promise.resolve().then(() => load())
  }, [])

  const visibleTasks = useMemo(() => {
    return tasks.filter(task => {
      if (selectedAgent !== 'all' && task.assignee !== selectedAgent) return false
      if (!showDone && task.status === 'done') return false
      return true
    })
  }, [tasks, selectedAgent, showDone])

  const activeTasks = visibleTasks.filter(task => task.status !== 'done')
  const doneTasks = visibleTasks.filter(task => task.status === 'done')
  const chiefById = Object.fromEntries(chiefs.map(chief => [chief.agentId, chief]))

  const persistPatch = async (taskId, payload) => {
    await fetch(`/api/pm-board/${taskId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
    load()
  }

  const createTask = async () => {
    await fetch('/api/pm-board', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...form, movedBy: 'Navi' })
    })
    setIsCreating(false)
    setEditingTask(null)
    setForm(emptyTask)
    setNote('')
    load()
  }

  const saveTask = async () => {
    if (isCreating) return createTask()
    await persistPatch(editingTask.id, { ...form, note, movedBy: 'Navi' })
    setEditingTask(null)
    setForm(emptyTask)
    setNote('')
  }

  const moveTask = async (task, nextStatus) => {
    await persistPatch(task.id, {
      status: nextStatus,
      note: `Status mogut a ${nextStatus}`,
      movedBy: chiefById[task.assignee]?.name || 'Navi'
    })
  }

  const archiveTask = async (task) => {
    await persistPatch(task.id, {
      status: 'done',
      note: 'Tasca completada i enviada a historial',
      movedBy: chiefById[task.assignee]?.name || 'Navi'
    })
  }

  const deleteTask = async (task) => {
    await persistPatch(task.id, {
      note: 'Marcada com descartada',
      movedBy: 'Navi',
      status: 'done'
    })
  }

  const openCreate = () => {
    setIsCreating(true)
    setEditingTask(null)
    setForm({ ...emptyTask, assignee: chiefs[0]?.agentId || '' })
    setNote('')
  }

  const openEdit = (task) => {
    setIsCreating(false)
    setEditingTask(task)
    setForm({
      title: task.title || '',
      description: task.description || '',
      assignee: task.assignee || '',
      priority: task.priority || 'media',
      status: task.status || 'todo',
      deliverableLink: task.deliverableLink || '',
    })
    setNote('')
  }

  const getTasksForStage = (stageId) => activeTasks.filter(task => task.status === stageId)

  return (
    <div className="task-pipeline">
      <div className="tp-header">
        <h2>Task Pipeline</h2>
        <div className="tp-header-actions">
          <span className="task-count">{activeTasks.length} actives · {doneTasks.length} fetes</span>
          <button className="tp-add-btn" onClick={openCreate}><Plus size={14} /> Nova</button>
        </div>
      </div>

      <div className="tp-agent-filters">
        <button className={`tp-agent-pill ${selectedAgent === 'all' ? 'active' : ''}`} onClick={() => setSelectedAgent('all')}>Tots</button>
        {chiefs.map(chief => (
          <button key={chief.agentId} className={`tp-agent-pill ${selectedAgent === chief.agentId ? 'active' : ''}`} onClick={() => setSelectedAgent(chief.agentId)}>
            {chief.emoji} {chief.name}
          </button>
        ))}
        <button className={`tp-agent-pill ${showDone ? 'active' : ''}`} onClick={() => setShowDone(!showDone)}>
          <CheckCircle2 size={13} /> Historial fetes
        </button>
      </div>

      <div className="kanban-board">
        {STAGES.map(stage => {
          const stageTasks = getTasksForStage(stage.id)
          return (
            <div key={stage.id} className="kanban-column" style={{ '--stage-color': stage.color }}>
              <div className="column-header">
                <div className="column-title-row">
                  <span className="column-dot" style={{ background: stage.color }} />
                  <span className="column-title">{stage.label}</span>
                </div>
                <span className="column-count">{stageTasks.length}</span>
              </div>
              <div className="column-body">
                {stageTasks.map(task => {
                  const chief = chiefById[task.assignee]
                  const priority = PRIORITY_CONFIG[task.priority] || PRIORITY_CONFIG.baixa
                  return (
                    <div key={task.id} className="task-card">
                      <div className="task-card-header">
                        <span className="task-agent-badge">{chief ? `${chief.emoji} ${chief.name}` : task.assignee}</span>
                        <span className="priority-badge" style={{ color: priority.color, background: priority.bg }}>{priority.label}</span>
                      </div>
                      <div className="task-title">{task.title}</div>
                      <div className="task-desc">{task.description}</div>
                      <div className="task-meta">
                        <span className="task-client">{task.id}</span>
                        <span className="task-due">{formatDate(task.updatedDate)}</span>
                      </div>
                      {Array.isArray(task.notes) && task.notes.length > 0 && (
                        <div className="task-blockers">
                          <MessageSquare size={12} />
                          <span>{task.notes[task.notes.length - 1].text}</span>
                        </div>
                      )}
                      <div className="task-actions-row">
                        {task.status !== 'in-progress' && <button className="task-action-btn" onClick={() => moveTask(task, 'in-progress')}>En curs</button>}
                        {task.status !== 'review' && <button className="task-action-btn" onClick={() => moveTask(task, 'review')}>Review</button>}
                        <button className="task-action-btn success" onClick={() => archiveTask(task)}>Feta</button>
                        <button className="task-icon-btn" onClick={() => openEdit(task)} title="Editar"><Pencil size={13} /></button>
                        <button className="task-icon-btn danger" onClick={() => deleteTask(task)} title="Eliminar"><Trash2 size={13} /></button>
                      </div>
                    </div>
                  )
                })}
                {stageTasks.length === 0 && <div className="column-empty">—</div>}
              </div>
            </div>
          )
        })}
      </div>

      {showDone && doneTasks.length > 0 && (
        <div className="done-history-panel">
          <h3><Clock3 size={15} /> Historial de fetes</h3>
          <div className="done-history-list">
            {doneTasks.map(task => {
              const chief = chiefById[task.assignee]
              return (
                <div key={task.id} className="done-history-item">
                  <div>
                    <strong>{task.title}</strong>
                    <div className="done-history-meta">{chief ? `${chief.emoji} ${chief.name}` : task.assignee} · {formatDate(task.updatedDate)}</div>
                  </div>
                  <div className="done-history-link">{task.deliverableLink ? 'Deliverable' : 'Sense link'}</div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {(editingTask || isCreating) && (
        <div className="tp-modal-overlay" onClick={() => { setEditingTask(null); setIsCreating(false) }}>
          <div className="tp-modal" onClick={e => e.stopPropagation()}>
            <div className="tp-modal-header">
              <h3>{isCreating ? 'Nova tasca' : 'Editar tasca'}</h3>
              <button className="task-icon-btn" onClick={() => { setEditingTask(null); setIsCreating(false) }}><X size={14} /></button>
            </div>
            <div className="tp-modal-body">
              <div className="tp-field">
                <label>Titol</label>
                <input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
              </div>
              <div className="tp-field">
                <label>Descripcio</label>
                <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
              </div>
              <div className="tp-grid-2">
                <div className="tp-field">
                  <label>Agent</label>
                  <select value={form.assignee} onChange={e => setForm({ ...form, assignee: e.target.value })}>
                    {chiefs.map(chief => <option key={chief.agentId} value={chief.agentId}>{chief.emoji} {chief.name}</option>)}
                  </select>
                </div>
                <div className="tp-field">
                  <label>Prioritat</label>
                  <select value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })}>
                    {PRIORITIES.map(priority => <option key={priority} value={priority}>{PRIORITY_CONFIG[priority].label}</option>)}
                  </select>
                </div>
              </div>
              <div className="tp-grid-2">
                <div className="tp-field">
                  <label>Estat</label>
                  <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                    {[...STAGES, { id: 'done', label: 'Done' }].map(stage => <option key={stage.id} value={stage.id}>{stage.label}</option>)}
                  </select>
                </div>
                <div className="tp-field">
                  <label>Deliverable link</label>
                  <input value={form.deliverableLink} onChange={e => setForm({ ...form, deliverableLink: e.target.value })} />
                </div>
              </div>
              {!isCreating && (
                <div className="tp-field">
                  <label>Comentari</label>
                  <textarea value={note} onChange={e => setNote(e.target.value)} placeholder="Comentari o actualitzacio" />
                </div>
              )}
            </div>
            <div className="tp-modal-footer">
              <button className="task-action-btn" onClick={() => { setEditingTask(null); setIsCreating(false) }}>Cancelar</button>
              <button className="task-action-btn success" onClick={saveTask}>{isCreating ? 'Crear' : 'Guardar'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
