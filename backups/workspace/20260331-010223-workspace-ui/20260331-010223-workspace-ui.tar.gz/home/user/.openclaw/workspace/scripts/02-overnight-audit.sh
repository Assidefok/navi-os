#!/bin/bash
# Automation 2: Overnight Self-Improvement (module-scoped)
# Runs at 03:00 - audits exactly one module and only proposes/applies changes inside its owned files

set -euo pipefail

WORKSPACE="/home/user/.openclaw/workspace"
TODAY="$(date +%Y-%m-%d)"
LOG_FILE="$WORKSPACE/memory/${TODAY}-audit.md"
OWNERSHIP_FILE="$WORKSPACE/config/module-ownership.json"
ISSUES_FOUND=0
FIXES_APPLIED=0
BLOCKED_COUNT=0

mkdir -p "$WORKSPACE/memory" "$WORKSPACE/config"

echo "# Overnight Self-Improvement Audit - $TODAY" > "$LOG_FILE"
echo "" >> "$LOG_FILE"

cd "$WORKSPACE"

MODULES=("Ops" "Brain" "Lab")
AUDIT_INDEX=$(( $(date +%s) / 86400 % 3 ))
AUDIT_MODULE="${MODULES[$AUDIT_INDEX]}"

echo "## Audit Target: $AUDIT_MODULE" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"

if [ ! -f "$OWNERSHIP_FILE" ]; then
  echo "- ERROR: module ownership file not found: $OWNERSHIP_FILE" >> "$LOG_FILE"
  exit 1
fi

mapfile -t ALLOWED_FILES < <(python3 - <<PY
import json
with open('$OWNERSHIP_FILE', 'r', encoding='utf-8') as f:
    data = json.load(f)
mod = data.get('$AUDIT_MODULE', {})
for item in mod.get('modules', []) + mod.get('components', []):
    print(item)
PY
)

echo "### Ownership Boundary" >> "$LOG_FILE"
echo "- Allowed files for $AUDIT_MODULE:" >> "$LOG_FILE"
for f in "${ALLOWED_FILES[@]}"; do
  echo "  - $f" >> "$LOG_FILE"
done
echo "" >> "$LOG_FILE"

is_allowed() {
  local candidate="$1"
  for allowed in "${ALLOWED_FILES[@]}"; do
    if [ "$candidate" = "$allowed" ]; then
      return 0
    fi
  done
  return 1
}

# 1. Module audit limited to owned files
echo "### Module Audit" >> "$LOG_FILE"
for rel in "${ALLOWED_FILES[@]}"; do
  full="$WORKSPACE/$rel"
  if [ -f "$full" ]; then
    TODO_COUNT=$(grep -nE 'TODO|FIXME|XXX' "$full" 2>/dev/null | wc -l || true)
    echo "- $(basename "$rel"): TODO/FIXME/XXX = $TODO_COUNT" >> "$LOG_FILE"
    if [ "$TODO_COUNT" -gt 0 ]; then
      ISSUES_FOUND=$((ISSUES_FOUND + TODO_COUNT))
    fi
  fi
done
echo "" >> "$LOG_FILE"

# 2. Cross-module leak detection
echo "### Cross-module Safety Check" >> "$LOG_FILE"
while IFS= read -r candidate; do
  rel="${candidate#./}"
  if is_allowed "$rel"; then
    echo "- Allowed candidate: $rel" >> "$LOG_FILE"
  else
    echo "- Blocked candidate (out of module): $rel" >> "$LOG_FILE"
    BLOCKED_COUNT=$((BLOCKED_COUNT + 1))
  fi
done < <(find navi-os/src -type f \( -name '*.jsx' -o -name '*.css' -o -name '*.js' \) | sort)
echo "" >> "$LOG_FILE"

# 3. Safe fixes, only inside allowed files
echo "### Safe Fixes Applied" >> "$LOG_FILE"
for rel in "${ALLOWED_FILES[@]}"; do
  full="$WORKSPACE/$rel"
  [ -f "$full" ] || continue

  # Normalize trailing whitespace only inside owned files
  if grep -q '[[:space:]]$' "$full" 2>/dev/null; then
    sed -i 's/[[:space:]]\+$//' "$full"
    echo "- Trimmed trailing whitespace: $rel" >> "$LOG_FILE"
    FIXES_APPLIED=$((FIXES_APPLIED + 1))
  fi

done

echo "" >> "$LOG_FILE"
echo "## Summary" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"
echo "| Metric | Value |" >> "$LOG_FILE"
echo "|--------|-------|" >> "$LOG_FILE"
echo "| Module Audited | $AUDIT_MODULE |" >> "$LOG_FILE"
echo "| Allowed Files | ${#ALLOWED_FILES[@]} |" >> "$LOG_FILE"
echo "| Issues Found | $ISSUES_FOUND |" >> "$LOG_FILE"
echo "| Fixes Applied | $FIXES_APPLIED |" >> "$LOG_FILE"
echo "| Blocked Out-of-Module Candidates | $BLOCKED_COUNT |" >> "$LOG_FILE"
echo "| Timestamp | $(date '+%H:%M:%S') |" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"
echo "---" >> "$LOG_FILE"
echo "*Audit completed at $(date)*" >> "$LOG_FILE"

echo "Audit complete: module=$AUDIT_MODULE allowed=${#ALLOWED_FILES[@]} issues=$ISSUES_FOUND fixes=$FIXES_APPLIED blocked=$BLOCKED_COUNT"
