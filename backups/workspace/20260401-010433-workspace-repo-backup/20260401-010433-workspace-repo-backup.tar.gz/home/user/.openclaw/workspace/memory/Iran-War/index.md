---
type: index
category: Guerra d'Iran
icon: ⚔️
description: Iran war and Middle East conflict news
tags: ['iran', 'middle-east', 'war', 'conflict']
created: 2026-03-31 23:47
---

# ⚔️ Guerra d'Iran

Iran war and Middle East conflict news

## Meta
- **Carpeta:** `memory/Iran-War/`
- **Total entrades:** 2
- **Darrer update:** 2026-03-31 23:47

## Tags
#iran #middle-east #war #conflict

## Entrades recents

### [[2026-03-31-22.00.md|2026-03-31 22:00]] 

- What’s behind Donald Trump’s interest in Iran’s Kharg Island?...
- Analysis: Hezbollah backs Iran ambassador as conflict deepens Lebanon rifts...
- Iran’s FM confirms contact with US envoy Witkoff, denies talks under way...

### [[2026-03-31-21.00.md|2026-03-31 21:00]] 

- Iran’s FM confirms contact with US envoy Witkoff, denies talks under way...
- US-Israel launch major attacks as Iranian authorities maintain defiance...
- One month of war on Iran cost Arab countries up to $194bn: UNDP...

---

*Generat automàticament per Navi OS*
*Vault: /home/user/.openclaw/workspace/memory/*
